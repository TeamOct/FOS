local updaterCore = luajava.bindClass("com.nekit508.SimpleUpdater");

function getFi(path)
    return luajava.newInstance("arc.files.Fi", path)
end

local configs = updaterCore.root:child(".updater/necessary-configs.json")

-- process dependencies.properties
local depsTemp = updaterCore.root:child(".updater/necessary-configs-templates/dependencies.properties")
local deps = getFi("dependencies.properties")
if not deps:exists() then
    deps:writeString(depsTemp:readString())
end